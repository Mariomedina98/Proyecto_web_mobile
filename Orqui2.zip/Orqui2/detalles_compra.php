<?php

$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");

$id=$_GET['id'];

$sql="SELECT * from compras where id='".$id."'   ";

$resultado=$mysqli->query($sql);
while($fila=$resultado->fetch_assoc()){

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Orquidea</title>

 
    <script src="js\validaciones.js"></script>

    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css\footer.css">
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

</head>
<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>

            <div class="sidebar-header">
                <h3>Bienvenido</h3>
            </div>

            <ul class="list-unstyled components">
                <p>Floreria Orquidea</p>
                
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Principal</a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href=""> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-box-arrow-in-right" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8.146 11.354a.5.5 0 0 1 0-.708L10.793 8 8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0z"/>
  <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 1 8z"/>
  <path fill-rule="evenodd" d="M13.5 14.5A1.5 1.5 0 0 0 15 13V3a1.5 1.5 0 0 0-1.5-1.5h-8A1.5 1.5 0 0 0 4 3v1.5a.5.5 0 0 0 1 0V3a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v10a.5.5 0 0 1-.5.5h-8A.5.5 0 0 1 5 13v-1.5a.5.5 0 0 0-1 0V13a1.5 1.5 0 0 0 1.5 1.5h8z"/>
</svg> Inicio Sesion</a>
                        </li>
                        <li>
                            <a href="">Registrate</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Compras</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href=""> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8 3.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5H4a.5.5 0 0 1 0-1h3.5V4a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M7.5 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0V8z"/>
</svg>  Nuevo</a>
                        </li>
                        <li>
                            <a href="listacom.php">  <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-list-ul" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg> Lista Compras</a>
                        </li>
                    </ul>
                </li>
                
                <li>
                    <a href="#pageSubmenu1" data-toggle="collapse" aria-expanded="false">Productos</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu1">
                        <li>
                            <a href="productos.php"> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8 3.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5H4a.5.5 0 0 1 0-1h3.5V4a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M7.5 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0V8z"/>
</svg>  Nuevo</a>
                        </li>
                        <li>
                            <a href="listaprodu.php"> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-list-ul" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg>  Lista productos</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#pageSubmenu2" data-toggle="collapse" aria-expanded="false">Proveedores</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu2">
                        <li>
                            <a href="proveedores.php"> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8 3.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5H4a.5.5 0 0 1 0-1h3.5V4a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M7.5 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0V8z"/>
</svg>   Nuevo</a>
                        </li>
                        <li>
                            <a href="listaprove.php">  <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-list-ul" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg> Lista proveedores</a>
                        </li>
                    </ul>
                </li>


             
                
               
            </ul>

            
                <li>
                    <a href="https://www.google.com/intl/es-419/gmail/about/" class="article">Asesoria Tecnica</a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Nueva Compra</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="index.php">Inicio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="">Inicio Sesion</a>
                            </li>
                            
                            
                        </ul>
                    </div>
                </div>
            </nav>

   <div align="center">
   <a href="listacom.php" class="btn btn-success">  <svg width="1.3em" height="1.3em" viewBox="0 0 16 16" class="bi bi-arrow-bar-left" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M5.854 4.646a.5.5 0 0 0-.708 0l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L3.207 8l2.647-2.646a.5.5 0 0 0 0-.708z"/>
  <path fill-rule="evenodd" d="M10 8a.5.5 0 0 0-.5-.5H3a.5.5 0 0 0 0 1h6.5A.5.5 0 0 0 10 8zm2.5 6a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 1 0v11a.5.5 0 0 1-.5.5z"/>
</svg> Regresar a lista de compras</a>
   </div>
<p></p>
  <div class="container">
  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4">
    <div class="col">
    <input type="hidden"  class="form-control input-sm" name="id" placeholder="Ejemplo 7351782764" value="<?php echo $fila['id'] ?>" >
    <label>EFECTIVO: </label>
    <input type="text"  class="form-control input-sm" name="efectivo"  value="<?php echo $fila['efectivo'] ?>" disabled >
     </div>
   
     <div class="col">
    <label >Fecha</label>
    <input type="text"  class="form-control input-sm" name="fecha_compra"  value="<?php echo $fila['fecha_compra'] ?>" disabled >
    </div>

    <div class="col">
    <label >Sucursal</label>
    <input type="text"  class="form-control input-sm" name="fecha_compra"  value="<?php echo $fila['sucursal'] ?>" disabled >
    </div>
    <?php    }   ?>
    
    <div class="col">
    <label>ABONO: </label>
    <input type="text" class="form-control input-sm" disabled>

    </div>
    <div class="col">
          
    <label>CREDITO: </label>
    <input type="text" class="form-control input-sm" disabled>

    </div>
   
  </div>
</div>
<!-- se acaban los datos para extraer -->


            <div class="line"></div>

<!-- aqui va la tabla para pder meter las compras si que si -->


<table class='table'>
    <thead>
    <tr>
    
    <td scope='col' style='background-color:#9ED7D7'>Producto</td>
    <td scope='col' style='background-color:#9ED7D7'>Precio Unitario</td>
    <td scope='col' style='background-color:#9ED7D7'>Cantidad</td>
    <td scope='col' style='background-color:#9ED7D7'>Total</td>
    <td scope='col' style='background-color:#9ED7D7'>Abono</td>
    <td scope='col' style='background-color:#9ED7D7'>Proveedor</td>
    <td scope='col' style='background-color:#9ED7D7'>Credito</td>
    <td scope='col' style='background-color:#9ED7D7'>Detalles</td>
    <td scope='col' style='background-color:#9ED7D7'>Opciones</td>
    </tr>
    </thead>
    <tbody>
    <?php

$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");

$id=$_GET['id'];

$sql="SELECT 
CONCAT (categorias.categoria,' - ', compra_productos.producto) AS nomproducto, 
compra_productos.cantidad,
compra_productos.precio,compra_productos.total,
compra_productos.proveedor,compra_productos.abono,compra_productos.credito,compra_productos.nota
FROM compra_productos ,
productos,categorias
WHERE
compra_productos.compra_id='".$id."'
AND compra_productos.producto_id=productos.id
AND productos.categoria_id=categorias.id
AND compra_productos.proveedor_id IS  NULL
AND compra_productos.deleted!=1

UNION all

SELECT CONCAT (categorias.categoria,' - ', compra_productos.producto) AS nomproducto, 
compra_productos.cantidad,
compra_productos.precio,compra_productos.total,
compra_productos.proveedor,compra_productos.abono,compra_productos.credito,compra_productos.nota

FROM compra_productos ,
productos ,proveedores,categorias
WHERE
compra_productos.compra_id='".$id."'
AND compra_productos.proveedor_id IS NOT  NULL
AND productos.categoria_id=categorias.id
AND compra_productos.producto_id=productos.id
AND compra_productos.proveedor_id=proveedores.telefono1
AND compra_productos.deleted!=1
ORDER BY nomproducto asc  " ;

$resultado=$mysqli->query($sql);
while($fila=$resultado->fetch_assoc()){

?>
    <tr>
    <td><?php echo $fila['nomproducto']  ?></td>
    <td><?php  echo $fila['precio']  ?></td>
    <td><?php  echo $fila['cantidad']  ?></td>
    <td><?php  echo $fila['total']  ?></td>
    <td><?php  echo $fila['abono']  ?></td>
    <td><?php  echo $fila['proveedor']  ?></td>
    <td><?php  echo $fila['credito']  ?></td>
    <td><?php  echo $fila['nota']  ?></td>
    <td> 
    <!--
    <a href="aunnolotengoohsiohsi" class="btn btn-warning">
    <svg width='1.3em' height='1.3em' viewBox='0 0 16 16' class='bi bi-pencil' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
        <path fill-rule='evenodd' d='M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z'/>
        <path fill-rule='evenodd' d='M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z'/>
      </svg>Modificar</a> -->
    <a href="aunnolotengo" class="btn btn-danger">
      <svg width="1.3em" height="1.3em" viewBox="0 0 16 16" class="bi bi-trash" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
      <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
    </svg>Eliminar</a> 
    </td>
    </tr>
    <?php } ?> 
      </tbody>
       
</table>
<!-- fin de la tabla ahora si que si carnalito -->



    <!--fin del mero mero chiraspelas-->    </div>
    
  
        <script src="js/jquery-3.2.1.min.js"></script>  

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
  
    <script type="text/javascript">
        $(document).ready(function () {
            
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });
            $('#dismiss').on('click', function () {
                $('#sidebar').removeClass('active');
            });
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').addClass('active');
                 $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>
    <script type="text/javascript">
// Campos Nombres
$(document).ready(function () {
        $("#efectivox").keyup(function () {
            var value = $(this).val();
            $("#efectivoy").val(value);
            
        });
       
    });
        //aqui es para la funcion de cancekar sepa
$(document).ready(function () {
    $('#cancel').click(function(){
        $('#efectivoy')[0].reset();
    });
});
</script>

    <!-- para la multiplicacion de3 campos en vivo y en directo apoco no-->    
    <script>
  function multi(){
    var total = 1;
    var change= false; //
    $(".monto").each(function(){
        if (!isNaN(parseFloat($(this).val()))) {
            change= true;
            total *= parseFloat($(this).val());
        }
    });
    
    total = (change)? total:0;
    document.getElementById('Costo').innerHTML = total;
}
    </script>
</body>
</html>