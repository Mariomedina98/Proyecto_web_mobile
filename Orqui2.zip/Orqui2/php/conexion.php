<?php 
	function conexion()
	{
		return $conexion=mysqli_connect("localhost","root","","compras_db_27062017");
	}

 ?>