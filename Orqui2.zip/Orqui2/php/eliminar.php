<?php
	require_once "conexion.php";
	$conexion=conexion();

        $telefono=$_GET['telefono'];
        
    $sql="UPDATE proveedores set  estatus='0' where telefono='".$telefono."' ";
    
    $result=mysqli_query($conexion,$sql);

            if($result=1){
                 echo  "<script> 
                 
                 window.location='../listaprove.php'; 
                 </script>" ;
                 
            }
            else{
                echo  "<script> alertify.error('fallo al eliminar'); </script>" ;
            }
?>