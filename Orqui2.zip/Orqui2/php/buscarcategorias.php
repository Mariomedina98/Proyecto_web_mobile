<?php
$mysqli = new mysqli ("localhost","root","", "compras_db_27062017");

$salida="";
$query=" SELECT id,categoria FROM categorias order by id ";

if(isset($_POST['consulta'])){
    $q=$mysqli->real_escape_string($_POST['consulta']);
    $query="SELECT id,categoria FROM categorias where id LIKE '%".$q."%' or categoria LIKE '%".$q."%'";
}
$resultado =$mysqli->query($query);
if($resultado->num_rows > 0){
    $salida.="<select  class='form-control' id='opcionesmenu'>
  
    
    ";
        
    while($fila =$resultado->fetch_assoc()){
        $salida.="
        <option value='".$fila['id']."'>".$fila['categoria']."</option>
        ";
}
$salida.="</select>";

}else{
$salida.="NO HAY DATOS";
}
echo $salida;
$mysqli -> close();
?>