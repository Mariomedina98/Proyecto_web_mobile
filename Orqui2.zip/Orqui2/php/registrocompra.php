<?php 

require_once "conexion.php";
$conexion=conexion();


		$efectivo=$_POST['efectivo'];
		$menu=$_POST['menu'];
		if(insertar()==1){
			echo 2;
		}else{
			$sql="INSERT into compras 
			(id,status,efectivo,sucursal)
				values 
			(UUID() ,'0','$efectivo','$menu')";
			echo $result=mysqli_query($conexion,$sql);
		}
		function insertar(){
		}

 ?>