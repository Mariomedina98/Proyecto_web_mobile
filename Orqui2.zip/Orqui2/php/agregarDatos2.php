<?php 

	require_once "conexion.php";
	$conexion=conexion();

		
		$compra=$_POST['primerox'];
		$producto=$_POST['controlBuscador'];
		$proveedor=$_POST['controlBuscador1'];
		$credito=$_POST['credito'];
		$cantidad=$_POST['nombre'];
		$abono=$_POST['abono'];
		$costo=$_POST['costo'];
		$preciounitario=$_POST['apellido'];
		$preciounitario=$_POST['apellido'];
		$nota=$_POST['nota'];
		

		if(insertar()==1){
			echo 2;
		}else{
			$sql="INSERT into compra_productos (id,compra_id,producto_id,proveedor_id,precio,cantidad,total,abono,credito,nota)
				values (UUID(),'$compra','$producto','$proveedor','$preciounitario','$cantidad','$costo','$abono','$credito','$nota') ";

			echo $result=mysqli_query($conexion,$sql);
		
		}
	


		function insertar(){
			
			
		}

 ?>