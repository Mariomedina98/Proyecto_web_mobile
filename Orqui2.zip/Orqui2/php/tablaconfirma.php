<?php
$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");

$salida="";
$query=" SELECT * FROM compras order by created desc limit 1";

if(isset($_POST['consulta'])){
    $q=$mysqli->real_escape_string($_POST['consulta']);
    $query="SELECT id,efectivo,created,sucursal 
    FROM compras
    WHERE  id LIKE '%".$q."%'
    OR efectivo LIKE '%".$q."%' 
    OR  created LIKE '%".$q."%' 
    OR  sucursal LIKE '%".$q."%' ";
}

$resultado =$mysqli->query($query);
if($resultado->num_rows > 0){
    $salida.="
    <p> </p>
    <p> </p>
    <p> </p>
    <p> </p>
    <br>
    <br>
    <br>
    <br>
    
    

    <div align='center'> 
        <h1>CONFIRMA COMPRA</h1>
    </div>
  
    <table class='table'>
    <thead>
    <tr>
   
    <td scope='col' style='background-color:#9ED7D7'>ID COMPRA</td>
    <td scope='col' style='background-color:#9ED7D7'>EFECTIVO</td>
    <td scope='col' style='background-color:#9ED7D7'>CREATED</td>
    <td scope='col' style='background-color:#9ED7D7'>SUCURSAL</td>
    <td scope='col' style='background-color:#9ED7D7'>CONFIRMA</td>
    </tr>
    </thead>
    <tbody> ";

    while($fila =$resultado->fetch_assoc()){
        $salida.="<tr>
        
        
        <td>".$fila['id']."</td>
        <td>".$fila['efectivo']."</td>
        <td>".$fila['created']."</td>
        <td>".$fila['sucursal']."</td>

        <td>
        <a href='compra_productos.php?id=".$fila['id']."' class='btn btn-success'>
        <svg width='1.3em' height='1.3em' viewBox='0 0 16 16' class='bi bi-pencil' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
  <path fill-rule='evenodd' d='M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z'/>
  <path fill-rule='evenodd' d='M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z'/>
</svg>
        Confirma compra</a>
        </td>
        </tr>";
}
$salida.="</tbody></table>";

}else{
$salida.="NO HAY DATOS";
}
echo $salida;


$mysqli -> close();
?>