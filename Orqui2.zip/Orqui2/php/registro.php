<?php 

	require_once "conexion.php";
	$conexion=conexion();

		$telefono=$_POST['telefono'];
		$proveedor=$_POST['proveedor'];
		$descripcion=$_POST['descripcion'];
		

		if(insertar()==1){
			echo 2;
		}else{
			$sql="INSERT into proveedores (telefono1,proveedor,descripcion,estatus)
				values ('$telefono','$proveedor','$descripcion','1')";
			echo $result=mysqli_query($conexion,$sql);
		}


		function insertar(){
			
			
		}

 ?>