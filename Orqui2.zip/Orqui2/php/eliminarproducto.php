<?php
	require_once "conexion.php";
	$conexion=conexion();

        $productoo=$_GET['producto'];
        
    $sql="UPDATE productos set  estatus='0' where producto='".$productoo."' ";
    
    $result=mysqli_query($conexion,$sql);

            if($result=1){
                 echo  "<script> 
                 
                 window.location='../listaprodu.php'; 
                 </script>" ;
                 
            }
            else{
                echo  "<script> alertify.error('fallo al eliminar'); </script>" ;
            }
?>