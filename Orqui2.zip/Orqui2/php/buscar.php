<?php
$mysqli = new mysqli ("localhost","root","", "compras_db_27062017");

$salida="";

$query=" SELECT 
P.producto, C.categoria 
from 
productos P 
JOIN categorias C 
ON P.categoria_id = C.id where estatus='1' order by categoria";
  

if(isset($_POST['consulta'])){

    $q=$mysqli->real_escape_string($_POST['consulta']);
    $query="SELECT P.producto, C.categoria FROM productos P join categorias C on P.categoria_id = C.id 
    where P.producto LIKE '%".$q."%' OR C.categoria LIKE '%".$q."%'
    " ;
    

}
$resultado =$mysqli->query($query);

if($resultado->num_rows > 0){

  $salida.="<table class='table'>
    <thead>
    <tr>
    <td scope='col' style='background-color:#9ED7D7'>PRODUCTO</td>
    <td scope='col' style='background-color:#9ED7D7'>CATEGORIA</td>
    <td scope='col' style='background-color:#9ED7D7'>OPCIONES</td>
    <td scope='col' style='background-color:#9ED7D7'>DETALLES</td>
    </tr>
    </thead>
    <tbody> ";

    while($fila =$resultado->fetch_assoc()){
        $salida.="<tr>
        <td>".$fila['producto']."</td>
        <td>".$fila['categoria']."</td>
        <td>
        <a href='editarproducto.php' class='btn btn-warning'>
        <svg width='1.3em' height='1.3em' viewBox='0 0 16 16' class='bi bi-pencil' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
        <path fill-rule='evenodd' d='M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z'/>
        <path fill-rule='evenodd' d='M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z'/>
      </svg>
      Modificar</a> 
        
      <a href='php/eliminarproducto.php?producto=".$fila['producto']."' class='btn btn-danger'>
      <svg width='1.3em' height='1.3em' viewBox='0 0 16 16' class='bi bi-trash' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
      <path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z'/>
      <path fill-rule='evenodd' d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z'/>
    </svg>
    
      Eliminar</a> </td>
        <td>
        <select  class='form-control-sm'>
    <option> HOY</option>
    <option> SEMANAL</option>
    <option> ESTE MES</option>
    <option> MES PASADO</option>
    <option> ANUAL</option>
    <option> AÑO PASADO</option>
    </select>
        <a href='#' class='btn btn-primary'><svg width='1.3em' height='1.3em' viewBox='0 0 16 16' class='bi bi-file-ruled' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
        <path fill-rule='evenodd' d='M4 1h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H4z'/>
        <path fill-rule='evenodd' d='M13 6H3V5h10v1zm0 3H3V8h10v1zm0 3H3v-1h10v1z'/>
        <path fill-rule='evenodd' d='M5 14V6h1v8H5z'/>
      </svg></a>  </td>
        </tr>";
}
$salida.="</tbody></table>";

}else{
$salida.="NO HAY DATOS";
}
echo $salida;
$mysqli -> close();
?>