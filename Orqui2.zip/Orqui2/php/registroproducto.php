<?php 

	require_once "conexion.php";
	$conexion=conexion();

		
		$nombreproducto=$_POST['nombreproducto'];
		$opciones=$_POST['opciones'];
		

		if(insertar()==1){
			echo 2;
		}else{
			$sql="INSERT into productos (id,producto,categoria_id,estatus)
				values (UUID(),'$nombreproducto','$opciones','1')";
			echo $result=mysqli_query($conexion,$sql);
		}


		function insertar(){
			
			
		}

 ?>