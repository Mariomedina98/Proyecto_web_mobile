<?php 
$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");


//conexion de variables
    $telefono=$_GET['id'];
    $telefonoP=$_GET['telefono'];
    $proveedorP=$_GET['proveedor'];
    $descripcionP=$_GET['descripcion'];
    
    
//metodo aja su
   
      
         
        if($telefonoP!=''||$proveedorP!=''||$descripcionP!=''){
            $sql2="UPDATE proveedores set  telefono1='".$telefonoP."', proveedor='".$proveedorP."',
            descripcion='".$descripcionP."' where telefono='".$telefono."' ";
            $resultado2=$mysqli->query($sql2);
            if($resultado2=1){
                 echo  "<script> 
                 
                 window.location='../listaprove.php'; </script>" ;
            }
            else{
                echo  "<script> alertify.error('fallo al modificar'); </script>" ;
            }
        }

?>
