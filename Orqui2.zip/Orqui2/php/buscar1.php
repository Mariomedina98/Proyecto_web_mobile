<?php
$mysqli = new mysqli ("localhost","root","", "compras_db_27062017");

$salida="";
//$query=" SELECT * FROM compras, compra_productos ";
$query="SELECT * from compras order by created DESC";
if(isset($_POST['consulta'])){
    $q=$mysqli->real_escape_string($_POST['consulta']);
    $query="SELECT id, efectivo, fecha_compra,sucursal from compras where id like '%".$q."%'
    or efectivo like '%".$q."%'
    or fecha_compra like '%".$q."%'
    or sucursal like '%".$q."%'";
    //  $query="SELECT abono,credito,fecha_compra,sucursal FROM compras, compra_productos 
    //WHERE abono LIKE '%".$q."%' OR  credito LIKE '%".$q."%' OR fecha_compra LIKE '%".$q."%' OR sucursal LIKE '%".$q."%'";

}
$resultado =$mysqli->query($query);
if($resultado->num_rows > 0){
    $salida.="<table class='table'>
    <thead>
    <tr>
    
    <td scope='col' style='background-color:#9ED7D7'>EFECTIVO</td>
    <td scope='col' style='background-color:#9ED7D7'>FECHA COMPRA</td>
    <td scope='col' style='background-color:#9ED7D7'>SUCURSAL</td>
    <td scope='col' style='background-color:#9ED7D7'>OPCIONES</td>
    </tr>
    </thead>
    <tbody> ";

    while($fila =$resultado->fetch_assoc()){
        $salida.="<tr>
        <td>".$fila['efectivo']."</td>
        <td>".$fila['fecha_compra']."</td>
        <td>".$fila['sucursal']."</td>
        <td>
        <a href='detalles_compra.php?id=".$fila['id']."' class='btn btn-success'>
        <svg width='1.3em' height='1.3em' viewBox='0 0 16 16' class='bi bi-list-check' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
  <path fill-rule='evenodd' d='M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3.854 2.146a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708L2 3.293l1.146-1.147a.5.5 0 0 1 .708 0zm0 4a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708L2 7.293l1.146-1.147a.5.5 0 0 1 .708 0zm0 4a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z'/>
</svg>Detalles</a>
        </td>
        </tr>";
}
$salida.="</tbody></table>";

}else{
$salida.="NO HAY DATOS";
}
echo $salida;
$mysqli -> close();
?>