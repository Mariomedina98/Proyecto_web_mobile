<?php 

	require_once "conexion.php";
	$conexion=conexion();

		
		$compra=$_POST['primerox'];
		$producto=$_POST['controlBuscador'];
			
		$cantidad=$_POST['nombre'];
		$abono=$_POST['abono'];
		$costo=$_POST['costo'];
		$preciounitario=$_POST['apellido'];
		$preciounitario=$_POST['apellido'];
		$nota=$_POST['nota'];
		

		if(insertar()==1){
			echo 2;
		}else{
			$sql="INSERT into compra_productos (id,compra_id,producto_id,precio,cantidad,total,abono,nota)
				values (UUID(),'$compra','$producto','$preciounitario','$cantidad','$costo','$abono','$nota') ";

			echo $result=mysqli_query($conexion,$sql);
		
		}
	


		function insertar(){
			
			
		}

 ?>