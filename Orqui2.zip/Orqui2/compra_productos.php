<?php

$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");

?>


<?php 
	$conexion=mysqli_connect('localhost','root','','compras_db_27062017');
	$sql="SELECT id,producto from productos";
    $result=mysqli_query($conexion,$sql);
 ?>
<?php

$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");

$sql="SELECT * FROM compras order by created DESC LIMIT 1  ";

$resultado=$mysqli->query($sql);
while($fila=$resultado->fetch_assoc()){

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Orquidea</title>
    <?php require_once "scripts.php"; ?>

    <link rel="stylesheet" type="text/css" href="js/select2.min.css">
    
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css\footer.css">
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
            crossorigin="anonymous"></script>
    
    <script src="js/select2.min.js"></script>


    </head>

<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>

            <div class="sidebar-header">
                <h3>Bienvenido</h3>
            </div>

            <ul class="list-unstyled components">
                <p>Floreria Orquidea</p>
                
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Principal</a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href=""> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-box-arrow-in-right" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8.146 11.354a.5.5 0 0 1 0-.708L10.793 8 8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0z"/>
  <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 1 8z"/>
  <path fill-rule="evenodd" d="M13.5 14.5A1.5 1.5 0 0 0 15 13V3a1.5 1.5 0 0 0-1.5-1.5h-8A1.5 1.5 0 0 0 4 3v1.5a.5.5 0 0 0 1 0V3a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v10a.5.5 0 0 1-.5.5h-8A.5.5 0 0 1 5 13v-1.5a.5.5 0 0 0-1 0V13a1.5 1.5 0 0 0 1.5 1.5h8z"/>
</svg>Inicio Sesion</a>
                        </li>
                        <li>
                            <a href="">Registrate</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Compras</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href=""> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8 3.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5H4a.5.5 0 0 1 0-1h3.5V4a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M7.5 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0V8z"/>
</svg>  Nuevo</a>
                        </li>
                        <li>
                            <a href="listacom.php"> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-list-ul" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg>  Lista Compras</a>
                        </li>
                    </ul>
                </li>
                
                <li>
                    <a href="#pageSubmenu1" data-toggle="collapse" aria-expanded="false">Productos</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu1">
                        <li>
                            <a href="productos.php"><svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8 3.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5H4a.5.5 0 0 1 0-1h3.5V4a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M7.5 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0V8z"/>
</svg>   Nuevo</a>
                        </li>
                        <li>
                            <a href="listaprodu.php"> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-list-ul" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg> Lista productos</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#pageSubmenu2" data-toggle="collapse" aria-expanded="false">Proveedores</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu2">
                        <li>
                            <a href="proveedores.php"> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8 3.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5H4a.5.5 0 0 1 0-1h3.5V4a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M7.5 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0V8z"/>
</svg>  Nuevo</a>
                        </li>
                        <li>
                            <a href="listaprove.php"> <svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-list-ul" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg>   Lista proveedores</a>
                        </li>
                    </ul>
                </li>


             
                
               
            </ul>

            
                <li>
                    <a href="https://www.google.com/intl/es-419/gmail/about/" class="article">Asesoria Tecnica</a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Nueva Compra</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="index.php">Inicio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="">Inicio Sesion</a>
                            </li>
                            
                            
                        </ul>
                    </div>
                </div>
            </nav>

    <!-- SE ACABA EL MENU CAGADO -->
    
<!-- EMPIEZA LOS INPUTS QUE VAN A TOMAR EL VALOR DE LA ULTIMA COMPRA GENERADA-->
<div class="container">
  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4">
    <div class="col">
    <input type="hidden" id="primero" class="form-control input-sm"  value="<?php echo $fila['id'] ?>" >
    
    <label>EFECTIVO: </label>
    <input type="text"  class="form-control input-sm" name="efectivo"  value="<?php echo $fila['efectivo'] ?>" disabled >
     </div>
   
     <div class="col">
    <label >Fecha</label>
    <input type="text"  class="form-control input-sm" name="fecha_compra"  value="<?php echo $fila['fecha_compra'] ?>" disabled >
    </div>

    <div class="col">
    <label >Sucursal</label>
    <input type="text"  class="form-control input-sm" name="fecha_compra"  value="<?php echo $fila['sucursal'] ?>" disabled >
    </div>
    
    
    <div class="col">
    <label>ABONO: </label>
    <input type="text" class="form-control input-sm" disabled>

    </div>
    <div class="col">
          
    <label>CREDITO: </label>
    <input type="text" class="form-control input-sm" disabled>
    <?php    }   ?>
    </div>
   
  </div>
</div>
<!-- FIN DE LA EXTRACCION DE LOS INPUTS-->
<p></p>





<!-- ahora si ya quedo -->
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-5">
        <div class="panel panel-primary">
        <p></p>

            <div class="panel panel-heading" align="center"><h4>Agregar nuevo</h4></div>
            <div class="panel panel-body">
               
<div class="cointainer">
  <form id="registrocompra" >
   <div class="form-group">
 
   
   
        <input type="hidden"  id="primerox"  class="form-control input-sm" disabled>
    

   <p></p>
   <label >Productos</label>
<section style="text-align: center;">
		<select id="controlBuscador" name="menuproducto" style="width: 50%">
			<?php while ($ver=mysqli_fetch_row($result)) {?>

			<option value="<?php echo $ver[0] ?>">
				<?php echo $ver[1] ?>
			</option>

			<?php  }?>
		</select>
	</section>
    <p></p>
  

    <label> Cantidad</label>
        <input type="text"  id="nombre" value="" class="monto form-control input-sm" onkeyup="multi();">
        <p></p>
        
        <label> Precio unitario</label>
        <input type="text"  id="apellido" class="monto form-control input-sm" onkeyup="multi();">
        <p></p>

        <label >sub total</label>
        <input type="text" id="costo" class="form-control input-sm" disabled>
<p></p>
        <label >Abono</label>
        <input type="text" id="abono" class="form-control input-sm">
<p></p>

<input name="chec" type="checkbox" id="chec" onchange="comprobar();"/>
<label for="chec">Compra credito</label>
  <p></p>
</div>
<!-- menu para credito solo estos-->
        <label >Credito</label>
        <input type="text" id="credito" class="form-control input-sm" readonly="true" >
<p></p>
<label >proveedor</label>                   
    <section style="text-align: center;" >
		<select id="controlBuscador1" name="menuproveedor" style="width: 50%"   >
        
                    <?php
                     $query = $mysqli -> query ("SELECT telefono,proveedor FROM proveedores Order by proveedor");
                    while ($valores = mysqli_fetch_array($query)) {
                    echo '<option value="'.$valores[telefono].'">'.$valores[proveedor].'</option>';
                     }
                    ?>

		</select>
	</section>
    <p></p>
    <label> Nota</label>
        <input type="text"  id="nota" value="" class="monto form-control input-sm" >
        <p></p>

        <span id="copy" onclick="copy_address()" class="btn btn-success">Guardar</span>
    <span id="adicionar" class="btn btn-success" type="button">Agregar</span>
  </div>
</form>
</div>
        </div>
    </div>
    <div class="col-sm-4"></div>
</div>
<div class="line"></div>
</div>

<p>Elementos en la Tabla:
  <div id="adicionados"></div>
</p>
<table  id="mytable" class="table table-bordered table-hover ">
  <tr>
    <th>Producto</th>
    <th>Proveedor</th>
    <th>cantidad</th>
    <th>precio unitario</th>
    <th>sub total</th>
    <th>Opciones</th>

  </tr>
</table>

</div>





  



    <!--fin del mero mero chiraspelas-->    </div>
    
    <!-- liberias src que se ocupan -->
 
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
   
<script>
 function comprobar()
{
  document.getElementById('credito','controlBuscador1').readOnly = !document.getElementById("chec").checked;
}
</script>

    <script language="javascript">
function copy_address() {
    document.getElementById('primerox').value = document.getElementById('primero').value;
}
</script>
<script type="text/javascript">
        $(document).ready(function () {
               $('#copy').click(function(){
                alertify.success("Guardado correctamente");
               });
            });
               
                  
                   </script>
<!-- scripts que no meti en otro lado por hueva -->
<script type="text/javascript">
        $(document).ready(function () {

               $('#adicionar').click(function(){
             
                if($('#primerox').val()==""){
                alertify.error("Guarda los datos primero");
                return false;
            }else if($('#controlBuscador').val()==""){
                alertify.error("Agrega el producto");
                return false;
            }else if($('#nombre').val()==""){
                alertify.error("agrega la cantidad");
                return false;
            }else if($('#apellido').val()==""){
                alertify.error("agrega el precio unitario");
                return false;
            }
            
if($('#credito').val()==""){
    cadena=
            "primerox=" + $('#primerox').val() +
            "&controlBuscador=" + $('#controlBuscador').val() +
                    "&controlBuscador1=" + $('#controlBuscador1').val()+
                    
                    "&nombre=" + $('#nombre').val()+
                    "&costo=" + $('#costo').val()+
                    "&abono=" + $('#abono').val()+
                    "&nota=" + $('#nota').val()+
                    "&apellido=" + $('#apellido').val();
                   
                 
                    $.ajax({
                        type:"POST",
                        url:"php/agregarDatos.php",
                        data:cadena,
                        success:function(r){

                            if(r==2){
                                
                            }
                            else if(r==1){
                                $('#registrocompra')[0].reset();
                                alertify.success("agregado con exito");
                            }else{
                                alertify.error("ya jala pero no inserta jajaja");
                            }
                        }
                    });

} else
{

            cadena=
            "primerox=" + $('#primerox').val() +
            "&controlBuscador=" + $('#controlBuscador').val() +
                    "&controlBuscador1=" + $('#controlBuscador1').val()+
                    "&credito=" + $('#credito').val()+
                    "&nombre=" + $('#nombre').val()+
                    "&costo=" + $('#costo').val()+
                    "&abono=" + $('#abono').val()+
                    "&nota=" + $('#nota').val()+
                    "&apellido=" + $('#apellido').val();
                   
                 
                    $.ajax({
                        type:"POST",
                        url:"php/agregarDatos2.php",
                        data:cadena,
                        success:function(r){

                            if(r==2){
                                
                            }
                            else if(r==1){
                                $('#registrocompra')[0].reset();
                                alertify.success("agregado con exito");
                            }else{
                                alertify.error("ya jala pero no inserta jajaja");
                            }
                        }
                    });
}
        });

         });
    </script>
<script>
      $(document).ready(function() {
//obtenemos el valor de los input

$('#adicionar').click(function() {
  var buscador = document.getElementById("controlBuscador").value;
  var buscador1 = document.getElementById("controlBuscador1").value;
  var nombre = document.getElementById("nombre").value;
  var apellido = document.getElementById("apellido").value;
  var costo = document.getElementById("costo").value;
  var i = 1; //contador para asignar id al boton que borrara la fila
  var fila = '<tr id="row' + i + '"><td>' + buscador +'</td><td>' +buscador1 +'</td><td>' + nombre + '</td><td>' + apellido + '</td><td>' + costo + '</td><td><button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">Quitar</button></td></tr>'; //esto seria lo que contendria la fila

  i++;

  $('#mytable tr:first').after(fila);
    $("#adicionados").text(""); //esta instruccion limpia el div adicioandos para que no se vayan acumulando
    var nFilas = $("#mytable tr").length;
    $("#adicionados").append(nFilas - 1);
    //le resto 1 para no contar la fila del header
    document.getElementById("apellido").value ="";
    document.getElementById("costo").value = "";
    document.getElementById("nombre").value = "";
    document.getElementById("controlBuscador1").value = "";
    document.getElementById("controlBuscador").value = "";
    
  });
$(document).on('click', '.btn_remove', function() {
  var button_id = $(this).attr("id");
    //cuando da click obtenemos el id del boton
    $('#row' + button_id + '').remove(); //borra la fila
    //limpia el para que vuelva a contar las filas de la tabla
    $("#adicionados").text("");
    var nFilas = $("#mytable tr").length;
    $("#adicionados").append(nFilas - 1);
  });
});
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$('#controlBuscador').select2();
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#controlBuscador1').select2();
	});
</script>


    <script type="text/javascript">
        $(document).ready(function () {
            
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });
            $('#dismiss').on('click', function () {
                $('#sidebar').removeClass('active');
            });
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').addClass('active');
                 $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>


<script>
  function multi(){
    var total = 1;
    var change= false; //
    $(".monto").each(function(){
        if (!isNaN(parseFloat($(this).val()))) {
            change= true;
            total *= parseFloat($(this).val());
        }
    });
    
    total = (change)? total:0;
    document.getElementById('costo').value = total;
}
    </script>

</body>
</html>

