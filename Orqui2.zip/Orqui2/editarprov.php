<?php

$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");

$telefono=$_GET['telefono'];

$sql="select * from proveedores where telefono='".$telefono."'   ";

$resultado=$mysqli->query($sql);
while($fila=$resultado->fetch_assoc()){

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Orquidea</title>
    <?php require_once "scripts.php"; ?>
    
 
  
    
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    
</head>
<body>

    
       
            <div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-5">
        <div class="panel panel-primary">
        <br>
            <div class="panel panel-heading" align="center"><h2>MODIFICAR PROVEEDOR</h2></div>
            <div class="panel panel-body">
                <div class="text-center">
                    <img src="img/logofor.png" class="rounded" style="Max-width: 20%">
                </div>
                <form method="GET" action="php/actualizarproveedor.php">
                <p></p>
               
                <input type="hidden"  class="form-control input-sm" name="id" placeholder="Ejemplo 7351782764" value="<?php echo $fila['telefono'] ?>" >
                <p></p>

                <label>Telefono</label>
                <input type="text"  class="form-control input-sm" name="telefono" placeholder="Ejemplo 7351782764" value="<?php echo $fila['telefono1'] ?>" >
                
                <p></p>                
                <label>Proveedor</label>
                <input type="text"  class="form-control input-sm" name="proveedor" placeholder="Nombre del proveedor"  value="<?php echo $fila['proveedor'] ?>">
               
                <p></p>
                <label>Descripcion</label>
                <input type="text"  class="form-control input-sm" name="descripcion" placeholder="De que empresa es " value="<?php echo $fila['descripcion'] ?>">

                <p></p>
                <div align="center">    
               <input type="submit" name="" value="Actualizar" class="btn btn-success">
                <span class="btn btn-danger"  ><a href="listaprove.php">Cancelar</a></span>
                
                </form>
              
                
                </div>
              </div>
        </div>
    </div>
    <div class="col-sm-4"></div>
</div>
<!--
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   -->
   <!-- Bootstrap JS -->
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
   

   
</body>
</html>
<?php }?>

