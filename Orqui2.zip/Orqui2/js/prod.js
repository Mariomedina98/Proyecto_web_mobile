$(buscar_datos());



function buscar_datos(consulta){
$.ajax({
    url:'php/buscarcategorias.php',
    type:'POST',
    dataType:'html',
    data: {consulta: consulta},
})
.done(function(respuesta){
$("#opciones").html(respuesta);
})
.fail(function(){
    console.log("error");
})

}