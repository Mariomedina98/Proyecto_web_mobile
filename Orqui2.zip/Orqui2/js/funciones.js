function agregardatos(idanterior,menuproducto,cantidad,preciounitario,costo,menuproveedor){
 
cadena="idanterior=" + idanterior +
        "&menuproducto=" + menuproducto+
        "&cantidad=" + cantidad+
        "&preciounitario=" + preciounitario+
        "&costo=" + costo+        
        "&menuproveedor=" + menuproveedor;

    $.ajax({
    type="POST",
    url="php/agregarDatos.php",
    data:cadena,
    success:function(r){
        if(r==1){
            $('#tabla').load('componentes/tabla.php');
            alertify.success("agregado con exito");
        }else{
            alertify.error("Fallo al agregar producto");
        }
    }

});


}