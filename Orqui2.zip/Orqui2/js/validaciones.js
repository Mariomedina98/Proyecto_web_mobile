function validaciones() {
	var  telefono;
	telefono = document.getElementById("efectivox").value;


	if ( telefono === "" ) {
		alert("TODOS LOS CAMPOS SON OBLIGATORIOS");
		return false;
	}
	else if (isNaN(telefono)) {
		alert("El telefono es incorrecto, solo deben ser numeros");
		return false;
	}

}