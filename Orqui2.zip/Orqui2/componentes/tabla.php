
<div align="center">

  <button class="btn btn-success" data-toggle="modal" data-target="#producto">
  <svg width="1.3em" height="1.3em" viewBox="0 0 16 16" class="bi bi-file-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M4 1h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H4z"/>
  <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V10a.5.5 0 0 1-1 0V8.5H6a.5.5 0 0 1 0-1h1.5V6a.5.5 0 0 1 .5-.5z"/>
  </svg>Agregar producto</button>
  </div>

<p></p>
<div class="row">
<table class='table'>
    <thead>
        <tr>
            <td scope='col' style='background-color:#9ED7D7'>Producto</td>
            <td scope='col' style='background-color:#9ED7D7'>Cantidad</td>
            <td scope='col' style='background-color:#9ED7D7'>Precio Unitario</td>
            <td scope='col' style='background-color:#9ED7D7'>Sub total</td>
            <td scope='col' style='background-color:#9ED7D7'>Proveedor</td>
            <td scope='col' style='background-color:#9ED7D7'>Credito</td>
            <td scope='col' style='background-color:#9ED7D7'>Opciones</td>
        </tr>
    </thead>
    <tbody>
        
    <?php 
            $mysqli = new mysqli ("localhost","root","", "compras_db_27062017");
            
            $sql="SELECT * FROM compra_productos where compra_id='84c85b1e-c14f-11ea-844f-089e0185d0b8'";
            
            $resultado=$mysqli->query($sql);
            while($fila=$resultado->fetch_assoc()){
            
        ?>
        <tr>
        
            <td> <?php echo $fila['producto'] ?> </td>
            <td> <?php echo $fila['cantidad'] ?> </td>
            <td> <?php echo $fila['precio'] ?> </td>
            <td> <?php echo $fila['total'] ?> </td>
            <td> <?php echo $fila['proveedor'] ?> </td>
            <td> <?php echo $fila['credito'] ?> </td>
           
          
            <td>
            <a href="" class="btn btn-danger">Eliminar</a>
            <a href="" class="btn btn-warning">Modificar</a>
            </td>
 
        </tr>
      
        <?php } ?>    
    </tbody>
    
</table>
</div>