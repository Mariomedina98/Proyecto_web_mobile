<?php

$mysqli = new mysqli ("localhost","root","",
"compras_db_27062017");

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Orquidea</title>

 
    <script src="js\validaciones.js"></script>

    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css\footer.css">
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

</head>
<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>

            <div class="sidebar-header">
                <h3>Bienvenido</h3>
            </div>

            <ul class="list-unstyled components">
                <p>Floreria Orquidea</p>
                
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Principal</a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="">Inicio Sesion</a>
                        </li>
                        <li>
                            <a href="">Registrate</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Compras</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="">  Nuevo</a>
                        </li>
                        <li>
                            <a href="listacom.php">  Lista Compras</a>
                        </li>
                    </ul>
                </li>
                
                <li>
                    <a href="#pageSubmenu1" data-toggle="collapse" aria-expanded="false">Productos</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu1">
                        <li>
                            <a href="productos.php">  Nuevo</a>
                        </li>
                        <li>
                            <a href="listaprodu.php">  Lista productos</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#pageSubmenu2" data-toggle="collapse" aria-expanded="false">Proveedores</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu2">
                        <li>
                            <a href="proveedores.php">  Nuevo</a>
                        </li>
                        <li>
                            <a href="listaprove.php">  Lista proveedores</a>
                        </li>
                    </ul>
                </li>


             
                
               
            </ul>

            
                <li>
                    <a href="https://www.google.com/intl/es-419/gmail/about/" class="article">Asesoria Tecnica</a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Nueva Compra</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="index.php">Inicio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="">Inicio Sesion</a>
                            </li>
                            
                            
                        </ul>
                    </div>
                </div>
            </nav>

            <div align="center">
<div class="col-lg-6" >
<div class="input-group mb-6">


  <input type="text" class="form-control" placeholder="Buscar registro" name ="caja_busqueda" id="caja_busqueda">
  
  <div class="input-group-append">

    <button class="btn btn-primary" type="button">Buscar</button>
  </div>
  </div>
  </div>
  <br>
  <a href="#" id="nomas" class="btn btn-success" data-toggle="modal" data-target="#modalnuevo" style="display: inline;">
  <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-file-earmark-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path d="M9 1H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h5v-1H4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1h5v2.5A1.5 1.5 0 0 0 10.5 6H13v2h1V6L9 1z"/>
  <path fill-rule="evenodd" d="M13.5 10a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1H13v-1.5a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M13 12.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0v-2z"/>
</svg> Nueva compra </a>

<div class="modal fade" id="modalnuevo" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" 
aria-labelledby="staticBackdropLabel" aria-hidden="true">
  
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">NUEVA COMPRA</h5>
        
      </div>
      <div class="modal-body">
      <form id="holasi" onsubmit="return validaciones();">
        <label >Efectivo</label>
        <input type="text" id="efectivox" name="" class="form-control input-sm" autofocus>
       
        <label >Fecha</label>
        <input type="date" id="fechax" name="" class="form-control input-sm" >
      </div>
      </form>
      <div class="modal-footer">
        <button type="button" id="cancel" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="submit" id="registronuevo" class="btn btn-success" data-dismiss="modal" onclick="mostrarBoton()" > Guardar</button>
      </div>
    </div>
  </div>
</div>
<!--fin del sepa ajaj peor delmodal -->
<!--INICIO DEL MODAL DE REGISTRO DE PRODUCTOS -->
<div class="modal fade" id="producto" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" 
aria-labelledby="staticBackdropLabel" aria-hidden="true">
  
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">NUEVO PRODUCTO</h5>
        
      </div>
      <div class="modal-body">
      <form id="holasi">
        <label >Producto</label>
        <select name="" id="menuproducto"  class="form-control input-sm" >
        <option value=""> --SELECCIONA-- </option>
            
        <?php
                     $query = $mysqli -> query ("SELECT categoria_id,producto FROM productos Order by producto");
                    while ($valores = mysqli_fetch_array($query)) {
                    echo '<option value="'.$valores[categoria_id].'">'.$valores[producto].'</option>';
                     }
        ?>
        </select>
        
        
    
    <label> Cantidad</label>
                     <p></p>
      <input type="text" name="Precio" id="Precio" value="" class="monto form-control input-sm" onkeyup="multi();">
    <label> Precio unitario</label>
      <input type="text" name="Cantidad" id="Cantidad" class="monto form-control input-sm" onkeyup="multi();">
                     <p></p>
                     <label >sub total</label>
    <label id="Costo" class="form-control input-sm"></label>
    
  </td>
</tr>
        

        <label >Provedor</label>
        <select  id="menu" name="" class="form-control input-sm" >
        <option value=""> -- SELECCIONA -- </option>

        <?php
                     $query = $mysqli -> query ("SELECT id,proveedor FROM proveedores order by proveedor");
                    while ($valores = mysqli_fetch_array($query)) {
                    echo '<option value="'.$valores[id].'">'.$valores[proveedor].'</option>';
                     }
        ?>
                     </select>
        
     
     
      </div>
      </form>
      <div class="modal-footer">
        <button type="button" id="cancel" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" id="registronuevo" class="btn btn-success" data-dismiss="modal" > Guardar</button>
      </div>
    </div>
  </div>
</div>
<!--FIN DEL MODAL DEL REGISTRO DE PRODUCTOS-->
<!-- INICIO DE MODAL PARA EL REGGISTRO DE PRODUCTOS A CREDITO-->
<div class="modal fade" id="productocredito" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" 
aria-labelledby="staticBackdropLabel" aria-hidden="true">
  
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">NUEVO PRODUCTO</h5>
        
      </div>
      <div class="modal-body">

      <form id="holasi">
        <label >Producto</label>
        <select name="" id="menuproducto"  class="form-control input-sm" >
        <option value=""> --SELECCIONA-- </option>
            
        <?php
                     $query = $mysqli -> query ("SELECT categoria_id,producto FROM productos Order by producto");
                    while ($valores = mysqli_fetch_array($query)) {
                    echo '<option value="'.$valores[categoria_id].'">'.$valores[producto].'</option>';
                     }
        ?>
        </select>
               <div class="container" >
      <div class="row" >
        <div class="col-xs-3" >
        <label >Cantidad</label>
        <input type="text" id="" name="" class="form-control " >
        </div>
        </div>
               </div>      
        <label >Precio unitario</label>
        <input type="text" id="" name="" class="form-control input-sm" >
  
        

        <label >Proveedor</label>
        <select  id="menu" name="" class="form-control input-sm" >
        <option value=""> -- SELECCIONA -- </option>

        <?php
                     $query = $mysqli -> query ("SELECT id,proveedor FROM proveedores order by proveedor");
                    while ($valores = mysqli_fetch_array($query)) {
                    echo '<option value="'.$valores[id].'">'.$valores[proveedor].'</option>';
                     }
        ?>
                     </select>
                     
        <label >credito</label>
        <input type="text" id="" name="" class="form-control input-sm" >
        
      </div>
      </form>
      
      <div class="modal-footer">
        <button type="button" id="cancel" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" id="registronuevo" class="btn btn-success" data-dismiss="modal" > Guardar</button>
      </div>
    </div>
  </div>
</div>

<!-- FIN DEL MODAL PARA EL REGISTRO DE PRODUCTOS A CREDITO-->
  <br><br>

  <div class="container">
  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4">
    <div class="col">
    <label>EFECTIVO: </label>
      <input type="text" id="efectivoy" class="form-control input-sm" disabled>
    
     </div>
    <div class="col">
    <label>ABONO: </label>
    <input type="text" class="form-control input-sm" disabled>

    </div>
    <div class="col">
          
    <label>CREDITO: </label>
    <input type="text" class="form-control input-sm" disabled>

    </div>
    <div class="col">
    <label >Fecha</label>
    <input type="text" id="fechay" class="form-control input-sm" disabled>
    </div>
  </div>
</div>
            <div class="line"></div>
    <div class="container">
    <!-- boton para el producto a compra normal-->
     <button class="btn btn-success" data-toggle="modal" data-target="#producto">
     <svg width="1.3em" height="1.3em" viewBox="0 0 16 16" class="bi bi-file-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M4 1h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H4z"/>
  <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V10a.5.5 0 0 1-1 0V8.5H6a.5.5 0 0 1 0-1h1.5V6a.5.5 0 0 1 .5-.5z"/>
</svg>Productos efectivo</button>
<!--Boton para el producto a credito-->
  <button class="btn btn-success" data-toggle="modal" data-target="#productocredito">
  <svg width="1.3em" height="1.3em" viewBox="0 0 16 16" class="bi bi-file-plus" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M4 1h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H4z"/>
  <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V10a.5.5 0 0 1-1 0V8.5H6a.5.5 0 0 1 0-1h1.5V6a.5.5 0 0 1 .5-.5z"/>
</svg>Productos credito</button>   
    
<p></p>
<!-- aqui va la tabla para pder meter las compras si que si -->

<table class='table'>
    <thead>
    <tr>
    
    <td scope='col' style='background-color:#9ED7D7'>Producto</td>
    <td scope='col' style='background-color:#9ED7D7'>Cantidad</td>
    <td scope='col' style='background-color:#9ED7D7'>P.U.</td>
    <td scope='col' style='background-color:#9ED7D7'>Proveedor</td>
    <td scope='col' style='background-color:#9ED7D7'>Credito</td>
    <td scope='col' style='background-color:#9ED7D7'>OPCIONES</td>
    </tr>
    </thead>
    <tbody>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td> 
    
    <a href="aunnolotengoohsiohsi" class="btn btn-warning">
    <svg width='1.3em' height='1.3em' viewBox='0 0 16 16' class='bi bi-pencil' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
        <path fill-rule='evenodd' d='M11.293 1.293a1 1 0 0 1 1.414 0l2 2a1 1 0 0 1 0 1.414l-9 9a1 1 0 0 1-.39.242l-3 1a1 1 0 0 1-1.266-1.265l1-3a1 1 0 0 1 .242-.391l9-9zM12 2l2 2-9 9-3 1 1-3 9-9z'/>
        <path fill-rule='evenodd' d='M12.146 6.354l-2.5-2.5.708-.708 2.5 2.5-.707.708zM3 10v.5a.5.5 0 0 0 .5.5H4v.5a.5.5 0 0 0 .5.5H5v.5a.5.5 0 0 0 .5.5H6v-1.5a.5.5 0 0 0-.5-.5H5v-.5a.5.5 0 0 0-.5-.5H3z'/>
      </svg>Modificar</a>
    <a href="aunnolotengo" class="btn btn-danger">
      <svg width="1.3em" height="1.3em" viewBox="0 0 16 16" class="bi bi-trash" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
      <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
    </svg>Eliminar</a> 
    </td>
    
    </tbody>
</table>
<!-- fin de la tabla ahora si que si carnalito -->


    <!--fin del mero mero chiraspelas-->    </div>
    
  
        <script src="js/jquery-3.2.1.min.js"></script>  

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });
            $('#dismiss').on('click', function () {
                $('#sidebar').removeClass('active');
            });
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').addClass('active');
                 $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>
    <script type="text/javascript">
// Campos Nombres
$(document).ready(function () {
        $("#efectivox").keyup(function () {
            var value = $(this).val();
            $("#efectivoy").val(value);
            
        });
       
    });
        
$(document).ready(function () {
    $('#cancel').click(function(){
        $('#efectivoy')[0].reset();
    });
});
</script>
<script>
        var btn_1 = document.getElementById('registronuevo');
        var btn_2 = document.getElementById('nomas');
        
        function mostrarBoton () {
            btn_1.style.display = 'inline';
            btn_2.style.display = 'none';
        }
    </script>
    
    <script>
  
  function multi(){
    var total = 1;
    var change= false; //
    $(".monto").each(function(){
        if (!isNaN(parseFloat($(this).val()))) {
            change= true;
            total *= parseFloat($(this).val());
        }
    });
    
    total = (change)? total:0;
    document.getElementById('Costo').innerHTML = total;
}
    </script>
</body>
</html>

<!-- extra-->
<?php 

	require_once "conexion.php";
	$conexion=conexion();

		$efectivo=$_POST['efectivo'];
		$menu=$_POST['menu'];
		$date=$_POST['date'];
		

		if(insertar()==1){
			echo 2;
		}else{
			$sql="INSERT into compras 
			(id,efectivo,app_id,fecha_compra,sucursal)
				values 
			(UUID(),'$efectivo','null','$date','$menu')";
			echo $result=mysqli_query($conexion,$sql);
		}


		function insertar(){
			
			
		}

 ?>